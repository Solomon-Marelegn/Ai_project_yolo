import yolov5
import pathlib
temp = pathlib.PosixPath
pathlib.PosixPath = pathlib.WindowsPath



model = yolov5.load(r"yolov5_best.pt")

def main():
    img = 'model_test/test_7.png'
    model_detected_result = model(img, size=500, augment=False)
    devices = get_devices(model_detected_result)
    labeled_devices = label_devices(devices)
    for i in labeled_devices:
        print(f'{i['class_name']} at {(i['x1'], i['y1'])},  {(i['x2'], i['y2'])}')
    
    
    print('\n')
    
    topology = get_topology(labeled_devices)
    for key, value in topology.items():
        print(f'{value[0]}', ' ' * (5 - len(value[0])) ,f'<-----{key}---->     {value[1]}')
  
def get_devices(model_detected_result):
    boxes = model_detected_result.xyxy[0]
    boxes = boxes.tolist()
    class_names = {0:'R', 1:'SW', 2:'FW', 3:'WAN', 4:'Eth'}
    devices = []
    
    for box in boxes:
        # boxes = [box1, box2, box3]
        # box1 = [x1, y1,....]

        x1 = box[0]
        y1 = box[1] 
        x2 = box[2]
        y2 = box[3]
        confidence = box[4] 
        class_id = box[5]

        x1, y1, x2, y2, class_id = int(x1), int(y1), int(x2), int(y2), int(class_id)
        class_name = class_names[class_id]

        entry = {'class_name': class_name,
                'x1':x1,
                'x2':x2,
                'y1':y1,
                'y2':y2,
                'confidence': confidence,
                'class_id': class_id}
            
        devices.append(entry)




    devices.sort(key=lambda device: device['x1']**2 + device['y1']**2)
    return devices

def label_devices(devices):
    tracker = {'R':0,
               'SW':0,
               'FW':0,
               'WAN':0,
                'Eth':0}

    for device in devices:
        dev_name = device['class_name']
        tracker[dev_name] += 1
        new_dev_name = dev_name + str(tracker[dev_name])
        device['class_name'] = new_dev_name
    
    return devices

def find_conn(device, eth, t_conn):
    offset = 50
    if t_conn == 't':
        is_connected =  ((device['x1'] - offset < eth['x1'] < device['x2'] + offset) and
            device['y1'] - offset <= eth['y2'] <= device['y1'] + offset)        

    elif t_conn == 'b':
        is_connected = ((device['x1'] - offset < eth['x1'] < device['x2'] + offset) and
            device['y2'] - offset <= eth['y1'] <= device['y2'] + offset)

    elif t_conn == 'r':
        is_connected = ((device['y1'] - offset < eth['y1'] < device['y2'] + offset) and
            device['x2'] - offset <= eth['x1'] <= device['x2'] + offset)

    elif t_conn == 'l':
        is_connected = ((device['y1'] - offset < eth['y2'] < device['y2'] + offset) and
            device['x1'] - offset <= eth['x2'] <= device['x1'] + offset)
    
    return is_connected

def find_neighbour(devices, eth, t_conn):
    for i in devices:
        if i['class_id'] != 4.0:
            if t_conn == 't':
                if find_conn(i, eth, 'b'):
                    return i
            
            elif t_conn == 'b':
                if find_conn(i, eth, 't'):
                    return i
                
            elif t_conn == 'r':
                if find_conn(i, eth, 'l'):
                    return i
            
            elif t_conn == 'l':
                if find_conn(i, eth, 'r'):
                    return i

def get_topology(devices):
    Topology = {}
    types_of_con = ['t','b','r','l']
    
    for dev in devices: 
        if dev['class_id'] != 4: 
            for eth in devices:
                if eth['class_id'] == 4:  
                    for t_conn in types_of_con:
                        if find_conn(dev, eth, t_conn):
                            #print(f'{eth['class_name']} {(eth['x1'], eth['y1'])},  {(eth['x2'], eth['y2'])} is connected to the ', dev['class_name'], 'from', t_conn)
                            neighbour = find_neighbour(devices, eth, t_conn)
                            if neighbour:
                                Topology[eth['class_name']] = [dev['class_name'], neighbour['class_name']]

    return Topology


main()





